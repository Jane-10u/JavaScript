

//独立COOKIE文件     ck在``里面填写，多账号换行

let zhimabodyVal= ``

let zhimatxbodyVal= ``

let zhimacookie = {

  zhimabodyVal: zhimabodyVal,  
  zhimatxbodyVal: zhimatxbodyVal,  
}

module.exports =  zhimacookie
  

